import style from "./index.css";
import Vue from "vue";
const app = new Vue({
  el: "#app",
  data: {
    message: "Hello Vue!"
  }
});