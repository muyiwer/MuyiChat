$(document).ready(function () {
    // Declare a proxy to reference the hub. 
    var chat = $.connection.MyHub;
    $.connection.hub.url = "http://localhost:81/signalr";
    var userId = sessionStorage.getItem('userId');
    chat.client.getFriendLastMessage = function (userID, data) {
        if (userID == userId) {
            console.log(data);
            console.log(data.NameAndMessage);
            console.log("updatedevent");
            $(".appendContacts").empty();
            $.each(data.NameAndMessage, function(key, val) {
                if(val.LastMessage == null){
                    $('.appendContacts').append('<li class="contact"> <div class="wrap"> <span class="contact-status online"></span> <img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><div class="meta"> <p class="name">'
                    + val.Name2 + '</p> <p class="preview">' 
                    + "" + '<p class="friendId" hidden>' + val.UserFriendId + '</p></div></div></li>');
                    console.log(val.Name);
                }else{
                    $('.appendContacts').append('<li class="contact"> <div class="wrap"> <span class="contact-status online"></span> <img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><div class="meta"> <p class="name">'
                    + val.Name2 + '</p> <p class="preview">' 
                    + val.LastMessage.Chatmessage + '<p class="friendId" hidden>' + val.UserFriendId + '</p></div></div></li>');
                    console.log(val.LastMessage.Chatmessage);
                }
               
                });
        }else{
            if(data.userFriendID == userId){
                console.log(data.userFriendID);
                console.log(data);
                console.log(data.NameAndMessageForFriend)
                $(".appendContacts").empty();
                $.each(data.NameAndMessageForFriend, function(key, val) {
                    if(val.LastMessage == null){
                        $('.appendContacts').append('<li class="contact"> <div class="wrap"> <span class="contact-status online"></span> <img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><div class="meta"> <p class="name">'
                        + val.Name2 + '</p> <p class="preview">' 
                        + "" + '<p class="friendId" hidden>' + val.UserFriendId + '</p></div></div></li>');
                        console.log(val.Name);
                    }else{
                        $('.appendContacts').append('<li class="contact"> <div class="wrap"> <span class="contact-status online"></span> <img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><div class="meta"> <p class="name">'
                        + val.Name2 + '</p> <p class="preview">' 
                        + val.LastMessage.Chatmessage + '<p class="friendId" hidden>' + val.UserFriendId + '</p></div></div></li>');
                        console.log(val.LastMessage.Chatmessage);
                    }
                   
                    });
            }
      
        }
    
    };



   // var connection = $.hubConnection("../signalr", { useDefaultPath: false });
   // $.connection.MyHub.start().done(init);
    // Create a function that the hub can call to broadcast messages.
    // Start the connection.
    $.connection.hub.start().done(function () {
            // Call the Send method on the hub. 
            chat.server.getContacts(userId).done(function(data) {
                sessionStorage.setItem('PhoneNumber',data.PhoneNumber);
                sessionStorage.setItem('CheckPhoneNumber',data.CheckPhoneNumber);
                $('#fullName').append(data.FullName);
                // if(data.CheckPhoneNumber == null){
                    $.each(data.NameAndMessage, function(key, val) {
                        if(val.LastMessage == null){
                            $('.appendContacts').append('<li class="contact"> <div class="wrap"> <span class="contact-status online"></span> <img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><div class="meta"> <p class="name">'
                            + val.Name2 + '</p> <p class="preview">' 
                            + "" + '<p class="friendId" hidden>' + val.UserFriendId + '</p></div></div></li>');
                            console.log(val.Name);
                        }else{
                            $('.appendContacts').append('<li class="contact"> <div class="wrap"> <span class="contact-status online"></span> <img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><div class="meta"> <p class="name">'
                            + val.Name2 + '</p> <p class="preview">' 
                            + val.LastMessage.Chatmessage + '<p class="friendId" hidden>' + val.UserFriendId + '</p></div></div></li>');
                            console.log(val.Name);
                        }
                       
                        });
                    console.log(data);
                // }else{
                //     $.each(data.NameAndMessage, function(key, val) {
                //         $('.appendContacts').append('<li class="contact"> <div class="wrap"> <span class="contact-status online"></span> <img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><div class="meta"> <p class="name">'
                //            + val.Name2 + '</p> <p class="preview">' 
                //            + val.LastMessage.Chatmessage + '<p class="friendId" hidden>' + val.UserFriendId + '</p></div></div></li>');
                //     });
                //     console.log(data);
                // }
               
            });
          
    });
 
});