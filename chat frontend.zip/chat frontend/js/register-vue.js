new Vue({
    el: '#register-vue',
    data:{
        registrationTab: false,
        Email: '',
        PhoneNumber: '',
        FirstName: '',
        LastName: '',
        Password: '',
        loginPhoneNumber: '',
        loginPassword: '',
        showSpinner: false,
        isDisabled: true
    },
    methods:{
        submitLogin: function () {
            this.showSpinner = true;
            this.isDisabled = false;
            this.$http.post('UserAccounts/Login',
                {
                    Email: this.Email,
                    PhoneNumber: this.PhoneNumber
                }).then(function (data) {
                    var userData = data.body.data;
                    sessionStorage.setItem('token', userData.Token.access_token);
                   // this.UserName = userData.UserDetails.UserName
                    window.location.href = 'Dashboard/Index';
                },
                (error) => {
                    this.showSpinner = false;
                    this.isDisabled = true;
                        notif({
                            msg: error.body.message,
                            type: "error",
                            timeout: 3000
                        });
                    });     
        }
    }
})