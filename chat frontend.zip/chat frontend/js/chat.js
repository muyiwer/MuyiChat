$(function () {
	var friendId = sessionStorage.getItem('FriendID');
	var userPhoneNumber = sessionStorage.getItem('userPhoneNumber');
	var friendPhoneNumber = sessionStorage.getItem('friendPhoneNumber');
	var userPhoneNumber2 = sessionStorage.getItem('userPhoneNumber2');
	var friendPhoneNumber2 = sessionStorage.getItem('friendPhoneNumber2');
	var CheckPhoneNumber = sessionStorage.getItem('CheckPhoneNumber');
$('.HomeContent').show();
$('.content').hide();
$('#contactSidePanel').hide();
$('#groupSidePanel').hide();
$('#addcontact').click( function(){
	$('#sidepanel').hide();
	$('#groupSidePanel').hide();
	$('#contactSidePanel').show();
});
$('.closeContactSideTab').click(function(){
	$('#contactSidePanel').hide();
	$('#groupSidePanel').hide();
	$('#sidepanel').show();
})
$('#addgroup').click( function(){
	$('#sidepanel').hide();
	$('#contactSidePanel').hide();
	$('#groupSidePanel').show();
});
$('.closegroupSideTab').click(function(){
	$('#groupSidePanel').hide();
	$('#sidepanel').show();
})

	//call signalr server hub class
	var chat = $.connection.MyHub;
	$.connection.hub.url = "http://localhost:81/signalr";
$(".messages").animate({ scrollTop: $(document).height() }, "fast");

$("#profile-img").click(function() {
	$("#status-options").toggleClass("active");
});

$(".expand-button").click(function() {
  $("#profile").toggleClass("expanded");
	$("#contacts").toggleClass("expanded");
});

$("#status-options ul li").click(function() {
	$("#profile-img").removeClass();
	$("#status-online").removeClass("active");
	$("#status-away").removeClass("active");
	$("#status-busy").removeClass("active");
	$("#status-offline").removeClass("active");
	$(this).addClass("active");
	
	if($("#status-online").hasClass("active")) {
		$("#profile-img").addClass("online");
	} else if ($("#status-away").hasClass("active")) {
		$("#profile-img").addClass("away");
	} else if ($("#status-busy").hasClass("active")) {
		$("#profile-img").addClass("busy");
	} else if ($("#status-offline").hasClass("active")) {
		$("#profile-img").addClass("offline");
	} else {
		$("#profile-img").removeClass();
	};
	
	$("#status-options").removeClass("active");
});
//append new message for user

// get new message from user friend using websocket
chat.client.AddNewMessage  = function (friendID, Reciever,message) {
	if(Reciever == userPhoneNumber){
		var friendId2 = sessionStorage.getItem('FriendID');
		console.log(friendID);
		console.log(friendId2);
		if(friendID == friendId2){
			console.log(friendId2);
			$('#messages').append('<li class="sent"><img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><p>'
			+ message + '</p>');
			$('.contact.active .preview').html('<span>You: </span>' + message);
			$('.messages').animate({
				scrollTop: $('.messages').get(0).scrollHeight
			}, 1500);
		}
	}

};

//create and send new message for user when submit button is clicked

$('.submit').click(function() {
	console.log("is clicking......");
	console.log(friendId);
	if(CheckPhoneNumber ==! userPhoneNumber2){
		console.log(CheckPhoneNumber);
		var message =  $(".message-input input").val();
		$('#messages').append('<li class="sent"><img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><p>'
		+ message + '</p>');
		$('.contact.active .preview').html('<span>You: </span>' + message);
		console.log(message);
		if($.trim(message) == '') {
			console.log("null message");
			return false;
		}else{
			console.log("executed");
			$.connection.hub.start().done(function () {
				var friendId2 = sessionStorage.getItem('FriendID');
				var chatConversation ={
					"UserFriendsId":friendId2,
					"Chatmessage": message,
					"Sender": userPhoneNumber,
					"Reciever": friendPhoneNumber
				 }
				chat.server.sendMessageToFriend(chatConversation).done(function() {
					$('.message-input input').val('');
				});
				
			});
		}
	}else if(CheckPhoneNumber == userPhoneNumber){
		console.log(CheckPhoneNumber);
		var message =  $(".message-input input").val();
		//newMessage(); 
		$('#messages').append('<li class="replies"><img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><p>'
		+ message + '</p></li>'); 
		$('.contact.active .preview').html('<span>You: </span>' + message);
		$('.messages').animate({
			scrollTop: $('.messages').get(0).scrollHeight
		}, 1500);
		console.log(message);
		if($.trim(message) == '') {
			console.log("null message")
			return false;
		}else{
			console.log("executed");
	
			$.connection.hub.start().done(function () {
				var friendId2 = sessionStorage.getItem('FriendID');
				var chatConversation2 ={
					"UserFriendsId":friendId2,
					"Chatmessage": message,
					"Sender": userPhoneNumber,
					"Reciever": friendPhoneNumber
				 }
				chat.server.sendMessageToFriend(chatConversation2).done(function() {
					$('.message-input input').val('');
				});
				
			});
		}
	}



});

// $(window).on('keydown', function(e) {
//   if (e.which == 13) {
//     newMessage();
//     return false;
//   }
// });

	
});