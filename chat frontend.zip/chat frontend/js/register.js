
$(function () {
  // on load of register html show register section hide login section
  $("#registrationTab").show();
  $("#loginTab").hide();
  // on click of login tab hide registration section show login section
  $("#login").click(function() {
    $("#registrationTab").hide();
    $("#loginTab").show();
  });
  // on click of registration tab show registration section hide login section
  $("#register").click(function() {
    $("#registrationTab").show();
    $("#loginTab").hide();
  });

  var register = $.connection.MyHub;
  $.connection.hub.url = "http://localhost:81/signalr";

  
 // var connection = $.hubConnection("../signalr", { useDefaultPath: false });
 // $.connection.MyHub.start().done(init);
  // Create a function that the hub can call to broadcast messages.
  
 
  // Start the connection.
  $.connection.hub.start().done(function () {
    //on click of register button
      $('.submitRegistration').click(function () {
        $(".submitRegistration").prop("disabled", true);
        $(".submitRegistration i").addClass("fa fa-spinner fa-spin");
          // gets user inputs
          var userDetails = {
            "Email": $('#email').val(),
            "PhoneNumber": $('#registerPhoneNumber').val(),
            "FirstName": $('#firstName').val(),
            "LastName": $('#lastName').val(),
            "Password": $('#registerPassword').val()
        };
        // Call the Register method of the hub class on server. 
          register.server.register(userDetails).done(function(data) {
            if(data.success == false){
              notif({
                msg: data.message,
                type: "error",
                timeout: 3000
              });
              $(".submitRegistration i").removeClass("fa fa-spinner fa-spin");
              $(".submitRegistration").prop("disabled", false);
            }else{
              sessionStorage.setItem('userId',data.Id)
              console.log(data.message);
              notif({
                msg: data.message,
                type: "success",
                timeout: 3000
              });
              $(".submitRegistration i").removeClass("fa fa-spinner fa-spin");
            $(".submitRegistration").prop("disabled", false);
              window.location.href = "./index.html";
            }
            
          });
      });

      // on click of the login button
      $('.submitLogin').click(function () {
        $(".submitLogin").prop("disabled", true);
        $(".submitLogin i").addClass("fa fa-spinner fa-spin");
        // Call the Login method of the hub class on server. 
          register.server.login( $('#loginPhoneNumber').val(), $('#loginPassword').val()).done(function(data) {
            if(data.success == false){
              notif({
                msg: data.message,
                type: "error",
                timeout: 3000
              });
              $(".submitRegistration i").removeClass("fa fa-spinner fa-spin");
              $(".submitRegistration").prop("disabled", false);
            }else{
              sessionStorage.setItem('userId',data.Id)
              console.log(data.message);
              notif({
                msg: data.message,
                type: "success",
                timeout: 3000
              });
              $(".submitRegistration i").removeClass("fa fa-spinner fa-spin");
            $(".submitRegistration").prop("disabled", false);
              window.location.href = "./index.html";
            }
            
          });
      });

  });
 

});


