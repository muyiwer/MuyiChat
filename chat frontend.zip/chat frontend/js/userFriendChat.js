$(function () {
    var chat = $.connection.MyHub;
    $.connection.hub.url = "http://localhost:81/signalr";
   
        $(document).on("click", ".contact", function() {
            $('.HomeContent').hide();
            $('.content').show();
            $("#messages").empty();
            $("#friendName").empty();
            var friendId = $('.friendId',this).text();
            var FriendName = $('.name',this).text();
            console.log(friendId);
            sessionStorage.setItem('FriendID',friendId);
            $.connection.hub.start().done(function () {
                chat.server.getMessageFromFriend(friendId).done(function(data) {
                    $('#friendName').append(FriendName);
                    sessionStorage.setItem('userPhoneNumber',data.userPhoneNumber);
                    sessionStorage.setItem('friendPhoneNumber',data.friendPhoneNumber);
                    sessionStorage.setItem('userPhoneNumber2',data.userPhoneNumber2);
                    sessionStorage.setItem('friendPhoneNumber2',data.friendPhoneNumber2);
                    console.log(data.userFriendConversations);
                    $.each(data.userFriendConversations, function(key, val) {
                        console.log(data.userPhoneNumber);
                        console.log(val.Reciever);
                        if(data.userPhoneNumber == val.Reciever)
                        {
                            $('#messages').append('<li class="sent"><img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><p>'
                            + val.Chatmessage + '</p>');
                            // $('.messages').animate({
                            //     scrollTop: $('.messages').get(0).scrollHeight
                            // }, 1500);
                            $('.messages').scrollTop($('.messages')[0].scrollHeight);
                         //   $('.messages').scrollTop($('.messages').height());
                            console.log("executed sent");
                        }
                        if(data.userPhoneNumber == val.Sender){
                           
                            $('#messages').append('<li class="replies"><img src="https://libertv.com/wp-content/uploads/2018/03/user-avatar-placeholder-1.png" alt="" /><p>'
                            + val.Chatmessage + '</p></li>'); 
                       
                            // $('.messages').animate({
                            //     scrollTop: $('.messages').get(0).scrollHeight
                            // }, 1500);
                            $('.messages').scrollTop($('.messages')[0].scrollHeight);
                           // $('.messages').scrollTop($('.messages').height());
                            console.log("executed reply");
                        }
                       
                    });
            });
            });
        }); 
});